<div style="height: 90px;"></div>
<div class="py-5 bg-light">
    <div class="container">
        <h1 class="h4">Kategori</h1>
        <ul>
            <li><a href="#">Teknik Informatika</a></li>
        </ul>
        <h1 class="h4">Perusahaan</h1>
        <ul>
            <li><a href="#">Teknik Informatika</a></li>
        </ul>
        <h1 class="h4">Lokasi Kerja</h1>
        <ul>
            <li><a href="#">Teknik Informatika</a></li>
        </ul>
    </div>
</div>
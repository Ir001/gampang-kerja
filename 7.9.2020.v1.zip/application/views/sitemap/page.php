<?='<?xml version="1.0" encoding="utf-8"?><?xml-stylesheet type="text/xsl" href="/assets/sitemap.xsl"?>';?>
    <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
        <url><loc><?=base_url()?></loc><changefreq>daily</changefreq><priority>1.0</priority></url>
        <url><loc><?=base_url('page/about');?></loc><lastmod><?=date('Y-m-d');?></lastmod><changefreq>weekly</changefreq><priority>0.6</priority></url>
        <url><loc><?=base_url('page/disclaimer');?></loc><lastmod><?=date('Y-m-d');?></lastmod><changefreq>weekly</changefreq><priority>0.6</priority></url>
        <url><loc><?=base_url('page/terms-of-use');?></loc><lastmod><?=date('Y-m-d');?></lastmod><changefreq>weekly</changefreq><priority>0.6</priority></url>
        <url><loc><?=base_url('page/privacy-policy');?></loc><lastmod><?=date('Y-m-d');?></lastmod><changefreq>weekly</changefreq><priority>0.6</priority></url>
        <url><loc><?=base_url('page/sitemap');?></loc><lastmod><?=date('Y-m-d');?></lastmod><changefreq>weekly</changefreq><priority>0.6</priority></url>
    </urlset>